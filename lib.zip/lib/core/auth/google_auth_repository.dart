import 'package:google_sign_in/google_sign_in.dart';
import 'app_user.dart';
import '../analytics/sheets_logger.dart';
import 'package:device_info_plus/device_info_plus.dart';

class GoogleAuthRepository implements AuthRepository {
  GoogleAuthRepository({GoogleSignIn? signIn})
      : _signIn = signIn ??
            GoogleSignIn(
              scopes: <String>[
                'email',
                // no Drive scope; we only need basic profile
              ],
            );

  final GoogleSignIn _signIn;

  Future<String> _deviceName() async {
    final d = DeviceInfoPlugin();
    try {
      final a = await d.androidInfo;
      return '${a.manufacturer} ${a.model}';
    } catch (_) {
      try {
        final i = await d.iosInfo;
        return '${i.utsname.machine}';
      } catch (_) {
        return 'Unknown Device';
      }
    }
  }

  @override
  Future<AppUser?> getCurrentUser() async {
    final acc = await _signIn.signInSilently();
    if (acc == null) return null;
    return AppUser(
      id: acc.id,
      displayName: acc.displayName ?? acc.email,
      email: acc.email,
    );
  }

  @override
  Future<AppUser?> signInWithGoogle() async {
    final acc = await _signIn.signIn();
    if (acc == null) return null;
    final user = AppUser(
      id: acc.id,
      displayName: acc.displayName ?? acc.email,
      email: acc.email,
    );
    final device = await _deviceName();
    await SheetsLogger.logSignup(user, device);
    return user;
  }

  @override
  Future<void> signOut() async {
    try {
      await _signIn.disconnect();
    } catch (_) {
      await _signIn.signOut();
    }
  }
}
